## 2. Sets ##

gender=[]
for each in legislators:
    gender.append(each[3])
gender=set(gender)
print(gender)
    

## 3. Exploring the Dataset ##

party=[]
for each in legislators:
    party.append(each[6])
party=set(party)
print(legislators)

## 4. Missing Values ##

for row in legislators:
    if row[3] == "":
        row[3] = "M"

## 5. Parsing Birth Years ##

birth_years=[]
for each in legislators:
    parts=each[2].split("-")
    birth_years.append(parts[0])
print(birth_years)    

## 6. Try/except Blocks ##

try:
    float("Hello")
except Exception:
    print("Error converting to float.")

## 7. Exception Instances ##

try:
    string=""
    int(string)
except Exception as ex:
    print(str(type(ex)))
    

## 8. The Pass Keyword ##

converted_years = []
for each in birth_years:
    year=each
    try:
        year=int(year)
    except Exception as ex:
        print("h")
    converted_years.append(year)

## 9. Convert Birth Years to Integers ##

for each in legislators:
    birthday=each[2]
    birth_year=birthday.split("-")[0]
    try:
        birth_year=int(birth_year)
    except Exception as ex:
        birth_year= 0
    each.append(birth_year)
    

## 10. Fill in Years Without a Value ##

last_value=1
for row in legislators:
    if row[7]==0:
        row[7]=last_value
    last_value=row[7]