## 2. Introduction to the Data ##

import csv 
file=open("nfl_suspensions_data.csv")
csvreader= csv.reader(file)
nfl_suspensions=list(csvreader)
nfl_suspensions=nfl_suspensions[1:]
years=dict()
for each in nfl_suspensions:
    year=each[5]
    if year in years:
        years[year]=years[year]+1
    else:
        years[year]=1
print(years)

## 3. Unique Values ##

games=[]
team=[]
for each in nfl_suspensions:
    team.append(each[1])
    games.append(each[2])
unique_teams=set(team)
unique_games=set(games)


## 4. Suspension Class ##

class Suspension:
    def __init__(self,each):
        self.name=each[0]
        self.team=each[1]
        self.games=each[2]
        self.year=each[5]
        
third_suspension = Suspension(nfl_suspensions[2]) 

## 5. Tweaking the Suspension Class ##

class Suspension:
    def __init__(self,row):
        self.name = row[0]
        self.team = row[1]
        self.games = row[2]
        self.year=row[5]
    def get_year(self):
        year=self.year
        try:
            year=int(year)
        except Exception as ex:
            year=0
        return year
missing_year=Suspension(nfl_suspensions[22])
twenty_third_year=missing_year.get_year()
print(twenty_third_year)