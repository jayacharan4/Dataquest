## 1. Geographic Data ##

import pandas as pd
airlines=pd.read_csv("airlines.csv")
airports=pd.read_csv("airports.csv")
routes= pd.read_csv("routes.csv")
print(airlines.head(1))
print(airports.head(1))
print(routes.head(1))

## 4. Workflow With Basemap ##

import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
m=Basemap(projection="merc",llcrnrlat=-80,urcrnrlat=80,llcrnrlon=-180,urcrnrlon=180)


## 5. Converting From Spherical to Cartesian Coordinates ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
lat=airports["latitude"].tolist()
lon=airports["longitude"].tolist()
x, y =m(lon,lat)


## 6. Generating A Scatter Plot ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
x, y = m(longitudes, latitudes)

m.scatter(x,y,s=1)
plt.show()

## 7. Customizing The Plot Using Basemap ##

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
longitudes = airports["longitude"].tolist()
latitudes = airports["latitude"].tolist()
x, y = m(longitudes, latitudes)
m.scatter(x, y, s=1)
m.drawcoastlines()
plt.show()

## 8. Customizing The Plot Using Matplotlib ##

# Add code here, before creating the Basemap instance.
fig,ax= plt.subplots(figsize=(15,20))
ax.set_title("Scaled Up Earth With Coastlines")

m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
longitudes = airports["longitude"].tolist()
latitudes = airports["latitude"].tolist()

x, y = m(longitudes, latitudes)
m.scatter(x, y, s=1)
m.drawcoastlines()
plt.show()

## 9. Introduction to Great Circles ##

geo_routes=pd.read_csv("geo_routes.csv")

geo_routes.info()

## 10. Displaying Great Circles ##

fig, ax = plt.subplots(figsize=(15,20))
m = Basemap(projection='merc', llcrnrlat=-80, urcrnrlat=80, llcrnrlon=-180, urcrnrlon=180)
m.drawcoastlines()
def create_great_circles(dataframe):
    for index,row in dataframe.iterrows():
        end_lat,start_lat=row["end_lat"],row["start_lat"]
        end_lon,start_lon=row["end_lon"],row["start_lon"]
        if (abs(end_lat-start_lat)<180)&(abs(end_lon-start_lon)<180):
            m.drawgreatcircle(start_lon,start_lat,end_lon,end_lat)
dfw_col=geo_routes["source"]=="DFW"       
dfw=geo_routes[dfw_col]
create_great_circles(dfw)
plt.show()