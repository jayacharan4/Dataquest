## 3. Read the File Into a String ##

f=open("dq_unisex_names.csv","r")
names= f.read()

## 4. Convert the String to a List ##

f = open('dq_unisex_names.csv', 'r')
names = f.read()
names_list=names.split("\n")
first_five=[]
counter=0
for each in names_list:
    first_five.append(each)
    counter=counter+1
    if counter>4:
        break
print(first_five)  

## 5. Convert the List of Strings to a List of Lists ##

f = open('dq_unisex_names.csv', 'r')
names = f.read()
names_list = names.split('\n')
nested_list=[]
for each in names_list:
    comma_list=each.split(",")
    nested_list.append(comma_list)
print(nested_list[0:5])


## 6. Convert Numerical Values ##

print(nested_list[0:5])
numerical_list=[]
for each in nested_list:
    name=each[0]
    value=float(each[1])
    newlist=[name,value]
    numerical_list.append(newlist)
print(numerical_list[0:5])

## 7. Filter the List ##

# The last value is ~100 people
numerical_list[len(numerical_list)-1]
thousand_or_greater=[]
for each in numerical_list:
    if (each[1]>=1000):
        thousand_or_greater.append(each[0])
print(thousand_or_greater[0:10])        