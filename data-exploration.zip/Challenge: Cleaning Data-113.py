## 3. Exploring the Data ##

import pandas as pd

avengers = pd.read_csv("avengers.csv")
avengers.head(5)

## 4. Filtering Out Bad Data ##

import matplotlib.pyplot as plt
true_avengers = pd.DataFrame()

true=avengers["Year"]>=1960
true_avengers=avengers[true]
avengers['Year'].hist()

## 5. Consolidating Deaths ##

def count_deaths(row):
    count=0
    columns=['Death1', 'Death2', 'Death3', 'Death4', 'Death5']
    
    for each in columns:
        col=row[each]
        if pd.isnull(col) or col=="NO":
            continue
        else :
            count+=1
    return count
true_avengers["Deaths"]=true_avengers.apply(count_deaths,axis=1)

## 6. Verifying Years Since Joining ##

joined_accuracy_count  = int()

year_since=avengers["Years since joining"]
year=true_avengers["Year"]

counts= 2015-year

joined_accuracy_count=len(counts)