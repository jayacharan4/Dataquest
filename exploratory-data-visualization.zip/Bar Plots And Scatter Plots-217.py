## 2. Introduction to the data ##

import pandas as pd
reviews=pandas.read_csv("fandango_scores.csv")
attr=["FILM","RT_user_norm","Metacritic_user_nom","IMDB_norm","Fandango_Ratingvalue","Fandango_Stars"]
norm_reviews=reviews[attr]
norm_reviews.head(1)

## 4. Creating Bars ##

import matplotlib.pyplot as plt
from numpy import arange
num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']

bar_heights = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75

fig,ax = plt.subplots()
ax.bar(bar_positions,bar_heights,0.5)
plt.show()


## 5. Aligning Axis Ticks And Labels ##

num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']
bar_heights = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75
tick_positions = range(1,6)

fig,ax = plt.subplots()
ax.bar(bar_positions,bar_heights,0.5)
ax.set_xticks(tick_positions)
ax.set_xticklabels(num_cols,rotation=90)
ax.set_xlabel("Rating Source")
ax.set_ylabel("Average Rating")
ax.set_title("Average User Rating For Avengers: Age of Ultron (2015)")
plt.show()

## 6. Horizontal Bar Plot ##

import matplotlib.pyplot as plt
from numpy import arange
num_cols = ['RT_user_norm', 'Metacritic_user_nom', 'IMDB_norm', 'Fandango_Ratingvalue', 'Fandango_Stars']

bar_widths = norm_reviews[num_cols].iloc[0].values
bar_positions = arange(5) + 0.75
tick_positions = range(1,6)

fig,ax= plt.subplots()
ax.barh(bar_positions,bar_widths,0.5)
ax.set_yticks(tick_positions)
ax.set_yticklabels(num_cols)
ax.set_ylabel("Rating Source")
ax.set_xlabel("Average Rating")
ax.set_title("Average User Rating For Avengers: Age of Ultron (2015)")
plt.show()

## 7. Scatter plot ##

ax,fig= plt.subplots()
fandango=norm_reviews["Fandango_Ratingvalue"]
rt=norm_reviews["RT_user_norm"]
fig.scatter(fandango,rt)
fig.set_xlabel('Fandango')
fig.set_ylabel('Rotten Tomatoes')
plt.show()

## 8. Switching axes ##

fig = plt.figure(figsize=(5,10))
ax1 = fig.add_subplot(2,1,1)
ax2 = fig.add_subplot(2,1,2)
fandango=norm_reviews["Fandango_Ratingvalue"]
rt=norm_reviews["RT_user_norm"]
ax1.scatter(fandango,rt,c="red")
ax1.set_xlabel("Fandango")
ax1.set_ylabel("Rotten Tomatoes")
ax2.scatter(rt,fandango)
ax2.set_xlabel("Rotten Tomatoes")
ax2.set_ylabel("Fandango")
plt.show()

## 9. Benchmarking correlation ##

import matplotlib.pyplot as plt

fig = plt.figure(figsize=(5,10))
ax1 = fig.add_subplot(3,1,1)
ax2 = fig.add_subplot(3,1,2)
ax3 = fig.add_subplot(3,1,3)
fandango=norm_reviews["Fandango_Ratingvalue"]
rt=norm_reviews["RT_user_norm"]
mt=norm_reviews["Metacritic_user_nom"]
imdb=norm_reviews["IMDB_norm"]

ax1.scatter(fandango,rt)
ax1.set_xlim(0,5)
ax1.set_ylim(0,5)

ax2.scatter(fandango,mt)
ax2.set_xlim(0,5)
ax2.set_ylim(0,5)

ax3.scatter(fandango,imdb)
ax3.set_xlim(0,5)
ax3.set_ylim(0,5)

plt.show()