## 2. Introduction to the Data ##

import pandas as pd
all_ages=pd.read_csv("all-ages.csv")

recent_grads=pd.read_csv("recent-grads.csv")

## 3. Summarizing Major Categories ##

# Unique values in Major_category column.
print(all_ages['Major_category'].unique())

aa_cat_counts = dict()
rg_cat_counts = dict()
def total_count(dataframe):
    dictionary={}
    unique_major=dataframe["Major_category"].unique()
    for each in unique_major:
        rows=dataframe[dataframe["Major_category"]==each]
        total=rows["Total"].sum()
        dictionary[each]=total
    return dictionary
aa_cat_counts=total_count(all_ages)    
rg_cat_counts=total_count(recent_grads)

## 4. Low-Wage Job Rates ##

low_wage_percent = 0.0

low_wage=recent_grads["Low_wage_jobs"].sum()
total=recent_grads["Total"].sum()
low_wage_proportion=low_wage/total
print(low_wage_proportion)

## 5. Comparing Data Sets ##

# All majors, common to both DataFrames
majors = recent_grads['Major'].unique()
rg_lower_count = 0
for each_major in majors:
    row_all_ages=all_ages[all_ages["Major"]==each_major]
    row_recent_grads=recent_grads[recent_grads["Major"]==each_major]
    
    aa_count=row_all_ages.iloc[0]["Unemployment_rate"]
    rg_count=row_recent_grads.iloc[0]["Unemployment_rate"]
    
    if rg_count<aa_count:
        rg_lower_count+=1
print(rg_lower_count)