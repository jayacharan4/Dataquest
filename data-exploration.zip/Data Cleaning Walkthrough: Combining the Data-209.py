## 3. Condensing the Class Size Data Set ##

class_size = data["class_size"]
fil1=class_size["GRADE "]=="09-12"
class_size=class_size[fil1]
fil2=class_size["PROGRAM TYPE"]=="GEN ED"
class_size=class_size[fil2]
print(class_size.head(5))

## 5. Computing Average Class Sizes ##

import numpy as np

class_size=class_size.groupby("DBN").agg(np.mean)
class_size.reset_index(inplace=True)
data["class_size"]=class_size
class_size.head(5)

## 7. Condensing the Demographics Data Set ##

data["demographics"] = data["demographics"][data["demographics"]["schoolyear"] == 20112012]
print(data["demographics"].head())

## 9. Condensing the Graduation Data Set ##

data["graduation"]=data["graduation"][data["graduation"]["Cohort"]=="2006"]
data["graduation"]=data["graduation"][data["graduation"]["Demographic"]=="Total Cohort"]
data["graduation"].head()

## 10. Converting AP Test Scores ##

import pandas as pd
cols = ['AP Test Takers ', 'Total Exams Taken', 'Number of Exams with scores 3 4 or 5']

ap_2010=data["ap_2010"]
for each in cols:
    ap_2010[each]=pd.to_numeric(ap_2010[each],errors="coerce")
print(ap_2010.dtypes)

## 12. Performing the Left Joins ##

combined = data["sat_results"]

combined=combined.merge(data["ap_2010"],how="left")
combined=combined.merge(data["graduation"],how="left")
print(combined.head(5))

print(combined.shape)

## 13. Performing the Inner Joins ##

lists=["class_size","demographics","survey","hs_directory"]
for each in lists:
    combined=combined.merge(data[each],how="inner")
print(combined.head())
print(combined.shape)

## 15. Filling in Missing Values ##

combined=combined.fillna(combined.mean())
combined=combined.fillna(0)
combined.head(5)

## 16. Adding a School District Column for Mapping ##

def two_char(col):
    return col[0:2]
combined["school_dist"]=combined["DBN"].apply(two_char)