## 1. Introduction ##

SELECT COUNT(Major) FROM recent_grads WHERE ShareWomen < 0.5

## 2. Finding a Column's Minimum and Maximum Values in SQL ##

select Major,Major_category, MIN(Median) 
from recent_grads
WHERE Major_category="Engineering"

## 3. Calculating Sums and Averages in SQL ##

select SUM(Total)
from recent_grads

## 4. Combining Multiple Aggregation Functions ##

select AVG(Total),MIN(Men),MAX(Women)
from recent_grads


## 5. Customizing The Results ##

select COUNT(*) as "Number of Students" , MAX(Unemployment_rate) "Highest Unemployment Rate" from recent_grads

## 6. Counting Unique Values ##

select count(DISTINCT(Major)) unique_majors , count(DISTINCT(Major_category)) unique_major_categories, count(DISTINCT(Major_code)) unique_major_codes 
from recent_grads


## 7. Performing Arithmetic in SQL ##

select Major,Major_category,(P75th - P25th) quartile_spread
from recent_grads
order by quartile_spread LIMIT 20