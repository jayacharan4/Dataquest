## 3. Introduction To The Data ##

import pandas as pd
import matplotlib.pyplot as plt

women_degrees = pd.read_csv('percent-bachelors-degrees-women-usa.csv')

x=women_degrees["Year"]
y=women_degrees["Biology"]
plt.plot(x,y)
plt.show()

## 4. Visualizing The Gender Gap ##

women_col=women_degrees["Biology"]

year=women_degrees["Year"]
plt.plot(year,women_col,c="blue",label="Women")
plt.plot(year,100-women_col,c="green",label="Men")
plt.title("Percentage of Biology Degrees Awarded By Gender")
plt.legend(loc="upper right")
plt.show()

## 6. Hiding Tick Marks ##

b_col=women_degrees["Biology"]
fig,ax= plt.subplots()
year=women_degrees["Year"]
plt.plot(year,b_col,c="blue",label="Women")
plt.plot(year,100-b_col,c="green",label="Men")
ax.tick_params(bottom="off",top="off",left="off",right="off")
plt.title("Percentage of Biology Degrees Awarded By Gender")
plt.legend(loc="upper right")
plt.show()


## 7. Hiding Spines ##

fig, ax = plt.subplots()
ax.plot(women_degrees['Year'], women_degrees['Biology'],c="blue", label='Women')
ax.plot(women_degrees['Year'], 100-women_degrees['Biology'],c="green", label='Men')
ax.tick_params(bottom="off", top="off", left="off", right="off")
# Add your code here

ax.legend(loc='upper right')
ax.set_title('Percentage of Biology Degrees Awarded By Gender')
for key,spine in ax.spines.items():
    spine.set_visible(False)
ax.legend(loc="upper right")
plt.show()


## 8. Comparing Gender Gap Across Degree Categories ##

major_cats = ['Biology', 'Computer Science', 'Engineering', 'Math and Statistics']
fig = plt.figure(figsize=(12, 12))

for sp in range(0,4):
    ax = fig.add_subplot(2,2,sp+1)
    ax.plot(women_degrees['Year'], women_degrees[major_cats[sp]], c='blue', label='Women')
    ax.plot(women_degrees['Year'], 100-women_degrees[major_cats[sp]], c='green', label='Men')
    # Add your code here.

for key,spines in ax.spines.items():
    spines.set_visible(False)
    ax.set_xlim(1968,2011)
    ax.set_ylim(0,100)
    ax.set_title(major_cats[sp])
    ax.tick_params(bottom="off", top="off", left="off", right="off")
   
# Calling pyplot.legend() here will add the legend to the last subplot that was created.
plt.legend(loc='upper right')
plt.show()
