## 1. Probability basics ##

# Print the first two rows of the data.
print(flags[:2])
bars_sorted = flags.sort_values("bars", ascending=[0])
most_bars_country = bars_sorted["name"].iloc[0]

population_sorted = flags.sort_values("population", ascending=[0])
highest_population_country = population_sorted["name"].iloc[0]

## 2. Calculating probability ##

total_countries = flags.shape[0]

orange_probability = flags[flags["orange"]==1].shape[0] / total_countries

stripe_probability = flags[flags["stripes"]>1].shape[0] / total_countries

## 3. Conjunctive probabilities ##

five_heads = .5 ** 5

ten_heads = .5 ** 10

hundred_heads = .5 ** 100

## 4. Dependent probabilities ##

# Remember that whether a flag has red in it or not is in the `red` column.
t = flags.shape[0]
red_count = flags[flags["red"]==1].shape[0]

three_red = ((red_count) * (red_count-1) * (red_count-2)) / (t * (t-1) * (t-2))

## 5. Disjunctive probability ##

start = 1
end = 18000

hundred_div = int(end/100)

seventy_div = int(end/70)

hundred_prob = hundred_div / end
seventy_prob = seventy_div / end

## 6. Disjunctive dependent probabilities ##

stripes_or_bars = None
red_or_orange = None
red = flags[flags["red"] == 1].shape[0] / flags.shape[0]
orange = flags[flags["orange"] == 1].shape[0] / flags.shape[0]
red_and_orange = flags[(flags["red"] == 1) & (flags["orange"] == 1)].shape[0] / flags.shape[0]

red_or_orange = red + orange - red_and_orange

stripes = flags[flags["stripes"] > 0].shape[0] / flags.shape[0]
bars = flags[flags["bars"] > 0].shape[0] / flags.shape[0]
stripes_and_bars = flags[(flags["stripes"] > 0) & (flags["bars"] > 0)].shape[0] / flags.shape[0]

stripes_or_bars = stripes + bars - stripes_and_bars

## 7. Disjunctive probabilities with multiple conditions ##

heads_or = None
head = 1/2
tail = head
heads_or =  1 - (1/2 ** 3)